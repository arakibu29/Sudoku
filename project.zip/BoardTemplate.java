public class BoardTemplate {
    private static final int COLUMN_COUNT = 3;
    private char[][] board;

    public BoardTemplate(char[][] board) {
        if (board == null || board.length != 3) {
            throw new IllegalArgumentException();
        }
        for (int i = 0; i < board.length; i++) {
            if (board[i].length != 3) {
                throw new IllegalArgumentException();
            }
        }
        this.board = board;
    }

    public BoardTemplate() {
        char[][] inputBoard = new char[COLUMN_COUNT][COLUMN_COUNT];
        // filled with nothing

        for (int i = 0; i < inputBoard.length; i++) {
            for (int j = 0; j < inputBoard[i].length; j++) {
                inputBoard[i][j] = ' ';
                // we'll use the spacebar character to represent
                // an empty cell

            }
        }
        this.board = inputBoard;
    }

    @Override
    public String toString() {
        String output = "";
        // could have also just done i < 3 here
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                // here's where we want to build the string
                output = output + board[i][j];
                if (j != 2) {
                    output += '|';
                }
                // we also want to include line breaks in the output somehow
            }
            output += "\n_____\n";
        }
        return output;
    }

    // Returns the index of the row that has three xs or three os,
    // or -1 if no row is a winning row
    public int checkWinningRow() {
        // board[0][0] == board[0][1] && board[0][1] == board[0][2] for row 0
        // board[1][0] == board[1][1] && board[1][1] == board[1][2] for row 1
        // board[2][0] == board[2][1] && board[2][1] == board[2][2] for row 2
        // board[i][0] == board[i][1] && board[i][1] == board[i][2] for row i

        // somehow express this in terms of is
        for (int i = 0; i < board.length; i++) {
            if (board[i][0] != ' ' && board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
                return i;
            }
        }
        return -1;

    }

    // Returns the index of the column that has three xs or three os,
    // or -1 if no column is a winning column.
    public int checkWinningColumn() {
        // j ranges 0 -> 2
        for (int j = 0; j < COLUMN_COUNT; j++) {
            if (board[0][j] != ' ' && board[0][j] == board[1][j] && board[1][j] == board[2][j]) {
                return j;
            }
        }
        return -1;
    }

    // Returns 0 if there are three xs or three os in the top left -> bottom right
    // diagonal, 1 if there are three xs or os in the bottom left -> top right
    // diagonal, and -1 if there is no winning diagonal.
    public int checkWinningDiag() {
        if (board[0][0] != ' ' && board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
            return 0;
        } else if (board[2][0] != ' ' && board[2][0] == board[1][1] && board[1][1] == board[0][2]) {
            return 1;
        }
        return -1;
    }

    public char getWinner() {
        if (checkWinningRow() > -1) {
            return board[checkWinningRow()][0];
        } else if (checkWinningColumn() > -1) {
            return board[0][checkWinningColumn()];
        } else if (checkWinningDiag() > -1) {
            return board[1][1];
        } else {
            return ' ';
        }
    }

    public void draw() {
        PennDraw.setPenColor(PennDraw.BLACK);
        PennDraw.setPenRadius(0.005);
        PennDraw.line(0.33, 0, 0.33, 1);
        PennDraw.line(0.66, 0, 0.66, 1);
        PennDraw.line(0, 0.33, 1, 0.33);
        PennDraw.line(0, 0.66, 1, 0.66);

        for (int i = 0; i < COLUMN_COUNT; i++) {
            for (int j = 0; j < COLUMN_COUNT; j++) {
                // could change the scale in pennDraw to go from 1 -> 0
                // get the y position and then flip it by subtracting it from 1
                double xPos = j / 3.0 + (1 / 6.0);
                double yPos = 1 - (i / 3.0 + (1 / 6.0));
                PennDraw.text(xPos, yPos, "" + board[i][j]);
            }
        }
    }

    public boolean update(int i, int j, char player) {
        if (board[i][j] == ' ') {
            board[i][j] = player;
            return true;
        } else {
            return false;
        }
    }

    public static void main(String[] args) {
        BoardTemplate tttb = new BoardTemplate();
        System.out.println(tttb);
        System.out.println(tttb.getWinner());
    }
}