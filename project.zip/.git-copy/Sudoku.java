/**
 * Author: Anuoluwa Akibu
 * Execution: java Sudoku
 * 
 * Description: Sudoku is the game class where the game is run. It takes in one
 * command line argument, which is a text file for a 9 x 9 Sudoku board, and 
 * creates a Board. All discrete, user interactions are handled here.
 */

public class Sudoku {
    public static void main(String[] args) {
        
        // 1. Sudoku will read in the file passed in the command line
        String filename = args[0];
        In inStream = new In(filename);
        String sudokuBoardSetUp = inStream.readAll();
                
        // 2. Sudoku will instantiate a Board object with values from file
        Board sudokuBoard = new Board(sudokuBoardSetUp);
        
        // 3. Sudoku is animated at 24 fps 
        PennDraw.enableAnimation(24); 
      
        // 4. Sudoku draws the Board object onto the users' screen
        PennDraw.clear();
        sudokuBoard.draw();
        
        // 5. I instantiated variables I use in the while loop here
        double mouseX = 0; // tracks x-coordinaete of mouse position
        double mouseY = 0; // tracks y-coordinate of mouse position
        char typed = ' '; // tracks the characters typed by user 
       
        // 6. The game begins running here:
        while (true) {
            /** 
             * 7. Checks whether the user has clicked the screen and stores the 
             * coordinates of their click if so. These coordinates, along with the 
             * empty char, are then passed to the Board which will react 
             * accordingly.
             */
            if (PennDraw.mousePressed()) {
                mouseX = PennDraw.mouseX();
                mouseY = PennDraw.mouseY();
                sudokuBoard.reactToInput(mouseX, mouseY, typed);
            
            
             // 8. Checks whether the user has typed anything. 
            if (PennDraw.hasNextKeyTyped()) {
                typed = PennDraw.nextKeyTyped(); // stores most recent key input
                 
            
            }// this is my implementation of clear, if the user presses the 
                 // space bar, everything they have inputted will be removed
            if (typed == ' ') {
                PennDraw.clear();
                sudokuBoard.clearAllInputs(); 
            }
                 
            /**
             * checks whether the users' keyboard input is a char between and 
             * including 1-9, if not the Board will not react, but if so, the
             * coordinates of the click and the key typed will be given to 
             * the Board to react accordingly 
             */
            if (typed < '1' || typed > '9') {
                continue;
            } else {
                sudokuBoard.clearLastInput(mouseX, mouseY);
            }
            sudokuBoard.reactToInput(mouseX, mouseY, typed);  
            } 
            
            /**
             * 9. Sudoku will check whether the end condition of Sudoku (the board
             * has been successfully completed with valid inputs) has been met. If
             * it has, the animation will be stopped and a celebratory message will
             * appear.
             */
            if (sudokuBoard.checkWinningBoard(sudokuBoard.getBoard())) {
                PennDraw.disableAnimation();
                PennDraw.setPenColor(PennDraw.WHITE);
                PennDraw.filledSquare(0.5, 0.5, 0.3);
                PennDraw.setPenColor(PennDraw.BLACK);
                PennDraw.text(0.5, 0.5, "BOARD COMPLETED! You have won!");
            }
            
            PennDraw.advance(); // advances the frame            
        }                 
    }
}
