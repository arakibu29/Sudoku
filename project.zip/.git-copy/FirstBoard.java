// /**
//  * Author: Anuoluwa Akibu
//  * Execution: java 
//  * 
//  * Description: 
//  */

// // write implements BoardInterface
// public class FirstBoard {
//     private static final int ROW_SIZE = 9;
//     private static final double CELL_WIDTH = 1.0 / 9.0;

//     /** FIELD **/
//     private Cell[][] board;

    
//     /** CONSTRUCTOR **/ 
//     public Board(String sudokuTextFile) {
       
//         // 1. Check if it's a 9x9 (check against textfile itself)
//         if (sudokuTextFile.length() != 89) {
//             throw new IllegalArgumentException("Invalid Sudoku Board!");
//         }
        
//         // 2. sets up double array with all possible positions of board
//         int index = 0;
//         double xPosition = CELL_WIDTH;
//         double yPosition = 8 * CELL_WIDTH;
         
//         // changed inputBoard to finalBoard
//         Cell[][] finalBoard = new Cell[ROW_SIZE][ROW_SIZE];
        
//         for (int i = 0; i < ROW_SIZE; i++) {
//             for (int j = 0; j < ROW_SIZE; j++) {
//                 if (sudokuTextFile.charAt(index) >= '1' && 
//                 sudokuTextFile.charAt(index) <= '9') {
//                     finalBoard[i][j] = new Cells(sudokuTextFile.charAt(index),
//                     xPosition, yPosition, false);
//                 } else {
//                     finalBoard[i][j] = new Cells(sudokuTextFile.charAt(index),
//                     xPosition, yPosition, true);
//                 } 
//                 index++;
//                 xPosition += CELL_WIDTH;
//             } 
//             index++;
//             xPosition = CELL_WIDTH;
//             yPosition -= CELL_WIDTH;
//         }
        
//         /** THROW THE EXCEPTIONS IF RETURNED FALSE **/
//         for (int i = 0; i < ROW_SIZE; i += 3) {
//             for (int j = 0; j < ROW_SIZE; j+= 3) {
//                 if (isRowValid(finalBoard) && isColumnValid(finalBoard) 
//                 && isThreeByThreeValid(finalBoard, i, j)) {        
//                    continue;
//                 } else {
//                     throw new IllegalArgumentException("Not a valid board!");
//             } 
//         }
        
//         this.board = finalBoard;
//     }
       
             
//     }
              
//     /** METHODS **/
//     public String toString() {
//         String outputBoard = "";
//         for (int i = 0; i < board.length; i++) {
//             for (int j = 0; j < board[i].length; j++) {
//                 outputBoard += board[i][j];
//             }
//         }
//         return outputBoard;
//     }
    
//     // draws the lines of the board and calls the indivudal cell draw
//     public void draw() {
//         PennDraw.setPenColor(PennDraw.BLACK);
//         double position = CELL_WIDTH;
        
//         int index = 0;
//         for (double i = 0.0; i < 0.99; i += position) {
//             if (index != 0 && index % 3 == 0) {
//                 PennDraw.setPenRadius(0.005);
//             } else {
//                 PennDraw.setPenRadius(0.002);
//             }
//             PennDraw.line(i, 0, i, 1);
//             PennDraw.line(0, i, 1, i);  
//             index++;
//         }
        
//         for (int i = 0; i < ROW_SIZE; i++) {
//             for (int j = 0; j < ROW_SIZE; j++) {
//                 PennDraw.text(board[i][j].getCenterX(), board[i][j].getCenterY(),
//                 "" + board[i][j].getCharOfCell()); 
//             }
//         }
//     }
        
    
//     /** METHODS **/
    
    
//     /** react to user input / maybe highlight problem numbers here? **/
//     /** error checking user input **/
   
//     public void reactToInput(double mouseX, double mouseY, char typed) {
//         int row = 0;
//         int column = 0;
            
//             // 1. find the cell where it's been clicked
//             for (int i = 0; i < ROW_SIZE; i++) {
//                 for (int j = 0; j < ROW_SIZE; j++) {
//                 // if the click's coordinate are within a cell's coordinates (acknowlegde all four corners)
//                     if (mouseX < board[i][j].getPosX()  && 
//                     mouseX > (board[i][j].getPosX() - CELL_WIDTH) && 
//                     mouseY < (board[i][j].getPosY() + CELL_WIDTH) && 
//                     mouseY > board[i][j].getPosY()) {
//                         row = i;
//                         column = j;
//                     }
//                 }              
//             }
        
//                // highlights square w/ a blue rectangle (doesn't remain blue)
//                PennDraw.setPenColor(221, 238, 254);
//                PennDraw.square(board[row][column].getCenterX(), 
//                board[row][column].getCenterY(), CELL_WIDTH / 2.0);  
        
//                if (typed == ' ') {
//                    return;
//                } else {
//                    if (board[row][column].getInteractiveField()) {
//                        System.out.println("interactive entered");
//                        board[row][column].reactToUserInput(typed);
//                    } else {
//                        System.out.println("Not interactive");
//                    }
//                }
             
//              if (typed < '1' || typed > '9') {
//                  return; 
//              } else {
//                  if (!isInputValid(board, row, column)) {
//                     for (int i = 0; i < ROW_SIZE; i++) {
//                         board[row][i].highlightIllegalInput();
//                         board[i][column].highlightIllegalInput(); 
//                         board[row][column].markIllegalInput();
//                     }
//                  }
//             }
//         }
    
 
//     // if this is false, call the cell's own highlight function
//     public boolean isInputValid(Cell[][] board, int row, int column) {     
//         boolean valid = true;
//         for (int i = 0; i < ROW_SIZE; i++) {
//             if (i != column) {
//                 if (board[row][i].getCharOfCell() == board[row][column].getCharOfCell()) {
//                   board[row][i].markIllegalInput();
//                     // if i need to mark problem values, here i would call the 
//                   // draw function to draw the text in red
//                    valid = false;
                  
//                 }
//             }
//             if (i != row) {
//                 if (board[i][column].getCharOfCell() == board[row][column].getCharOfCell()) {
//                   board[i][column].markIllegalInput();
//                     // if i need to mark problem values, here i would call the 
//                   // draw function to draw the text in red
//                    valid = false;
//                 }
//             }
//         }
             
//         return valid;
//     }
        
// //     /** TO IMPLEMENT **/
// //     /** error checking board  **/
//     public boolean isRowValid(Cell[][] inputBoard) {
//         int rowIndex = 0;
//         while (rowIndex < ROW_SIZE) {
//             Cell[] row = inputBoard[rowIndex];
//             for (int i = 0; i < ROW_SIZE; i++) {
//                 for (int j = i + 1; j < ROW_SIZE; j++) {
//                     if (row[i].getCharOfCell() == ' ') {
//                         break;
//                     } else if (row[i].getCharOfCell() == row[j].getCharOfCell()) {
//                         return false;
//                     }
//                 }
//             }
//             rowIndex++; 
//         }
//         return true;
//     }
        
//     public boolean isColumnValid(Cell[][] inputBoard) {
//         int columnIndex = 0;
//         while (columnIndex < ROW_SIZE) {
//             for (int i = 0; i < ROW_SIZE; i++) {
//                 char charToCheck = inputBoard[i][columnIndex].getCharOfCell();
//                 for (int j = i + 1; j < ROW_SIZE; j++) {
//                     if (charToCheck == ' ') {
//                         break;
//                     } else if (charToCheck == inputBoard[j][columnIndex].getCharOfCell()) {
//                         return false;
//                     } 
//                 }
//             }
//             columnIndex++;
//         }
//         return true;
//     }
    
//     public boolean isThreeByThreeValid(Cell[][] inputBoard, int row, int column) {
//         if (row % 3 != 0 && column % 3 != 0) {
//             throw new IllegalArgumentException("Invalid index!");
//         }
       
//         char[][] threeByThree = new char[3][3];
//         int columnIndex = column;
//         for (int i = 0; i < threeByThree.length; i++) {
//             for (int j = 0; j < threeByThree[i].length; j++) {
//                 threeByThree[i][j] = inputBoard[row][column].getCharOfCell();
//                 column++;
//             }
//             row++;
//             column = columnIndex;
//         }
        
//         int threeByThreeIndex = threeByThree.length;
//         int rowIndex = 0;
//         columnIndex = 0;
//         while (threeByThreeIndex > 0) {
//             char charToCheck = threeByThree[rowIndex][columnIndex];
//             for (int i = 0; i < 3; i++) {
//                 for (int j = 0; j < 3; j++) {
//                     if (charToCheck == ' ' || (rowIndex == i && columnIndex == j)) {
//                         continue; 
//                     } else if (charToCheck == threeByThree[i][j]) {
//                         return false;
//                     }
//                 }
//                 threeByThreeIndex--;
//             }
//             columnIndex++;
//             if (columnIndex == 3) {
//                 rowIndex++;
//                 columnIndex = 0;
//             }
//         } 
//         return true;
//     }
                           
    
//     /** winning board check **/
// //      public boolean checkWinningBoard(Cell[][] inputBoard) {
// //        for (int i = 0; i < ROW_SIZE; i += 3) {
// //            for (int j = 0; j < ROW_SIZE; j+= 3) {
// //                if (isThreeByThreeValid(inputBoard, i, j)) {
// //                    continue;
// //                } else {
// //                    return false;
// //                }
// //            }
// //        }
// //        return true;
// //    }
// }
