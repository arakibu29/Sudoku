/**
 * Author: Anuoluwa Akibu
 * Execution: java Cells
 * 
 * Description: Cells are objects of the Board. They represent each individual 
 * square of the board. Anything that requires individual reaction to a users's
 * input occurs through these methods.
 */

public class Cells implements Cell {
    
    /** FIELDS **/
    private static final double CELL_WIDTH = 1.0 / 9.0;
    private char charOfCell;
    private double xPos;
    private double yPos;
    private double xCenter; 
    private double yCenter;
    private boolean isInteractive; 
    
    /** CONSTRUCTOR **/
    public Cells(char charOfCell, double xPos, double yPos, boolean isInteractive) {
        this.charOfCell = charOfCell;
        this.xPos = xPos;
        this.yPos = yPos;
        this.xCenter = this.xPos - (CELL_WIDTH / 2.0);
        this.yCenter = this.yPos + (CELL_WIDTH / 2.0);
        if (charOfCell == ' ') {
            this.isInteractive = true;
        } else {
            this.isInteractive = false;
        }
    }
    
   /** GETTER METHODS **/
    public char getCharOfCell() {
        return charOfCell;
    }
    
    public double getPosX() {
        return xPos;
    }
    
    public double getPosY() {
        return yPos;
    }
    
    public double getCenterX() {
        return xCenter;
    }
    
    public double getCenterY() {
        return yCenter;
    }
   
    public boolean getInteractiveField() {
        return isInteractive;
    }
    
    /**
    * Description: Each cell will be able to draw itself (the number or empty space) 
    * onto the board
    * 
    * Input: none
    * Output: none
    */ 
    public void draw() {
        PennDraw.setPenColor(PennDraw.BLACK);
        PennDraw.square(xCenter, yCenter, CELL_WIDTH / 2.0); 
        PennDraw.text(xCenter, yCenter, "" + charOfCell);
    }
        
   /**
    * Description: This method draws illegal chars' square in red. it is called in react to 
     * user input of the Board during error checking
    * 
    * Input: a boolean that will tell the cell whether this method should be 
    * called or not
    * Output: none
    */ 
    public void highlightIllegalInput(boolean illegalMoveMade) {       
        if (illegalMoveMade) {
            PennDraw.setPenColor(PennDraw.WHITE);
            PennDraw.square(xCenter, yCenter, CELL_WIDTH / 2.0);
            PennDraw.setPenColor(PennDraw.RED);
            PennDraw.square(xCenter, yCenter, CELL_WIDTH / 2.0);                
        } else {
            PennDraw.setPenColor(PennDraw.WHITE);
            PennDraw.square(xCenter, yCenter, CELL_WIDTH / 2.0);
            PennDraw.setPenColor(PennDraw.BLACK);
            this.draw();
        }
    }

     /**
    * Description: This method draws the users' input char text and conflicitng 
    * chars of the board in red
    * 
    * Input: a boolean that will tell the cell whether this method should be 
    * called or not
    * Output: none
    */ 
    public void markIllegalInput(boolean illegalMoveMade) {
        if (illegalMoveMade) {
            PennDraw.setPenColor(PennDraw.WHITE);
            PennDraw.filledSquare(xCenter, yCenter, CELL_WIDTH / 3.0);
            PennDraw.setPenColor(PennDraw.RED);
            PennDraw.text(xCenter, yCenter, "" + charOfCell);    
        } else {
            PennDraw.setPenColor(PennDraw.WHITE);
            PennDraw.filledSquare(xCenter, yCenter, CELL_WIDTH / 3.0);
            PennDraw.setPenColor(PennDraw.BLACK);
            PennDraw.text(xCenter, yCenter, "" + charOfCell);  
        }
    }
    
  
    
   /**
    * Description: This method is how the cell reacts to the Board calling it to
    * react to the users' input. Cells must react to user click or not if 
    * clicked out of the cells' box cooridinates.  If a cell is clicked the number 
    * should NOT change unless a key has been pressed nd this key must be 
    * 1-9 or char '' (whitespace).
    * 
    * Input: the users' char typed
    * Output: none
    */  
    public void reactToUserInput(char typed) {        
        char current = charOfCell;
        if (typed >= '1' && typed <= '9') {
            charOfCell = typed; 
            
            PennDraw.setPenColor(PennDraw.WHITE);
            PennDraw.square(xCenter, yCenter, CELL_WIDTH / 3.0);
            System.out.println("draws white square");

            PennDraw.setPenColor(PennDraw.BLACK);
            PennDraw.text(xCenter, yCenter, "" + charOfCell);
        } else {
            charOfCell = current;
        } 
            PennDraw.advance();
        }
    
}  
          
