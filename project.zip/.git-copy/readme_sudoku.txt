/**********************************************************************
 *  readme template
 *  Project: Sudoku
 **********************************************************************/

Name: Anuoluwa Akibu
PennKey: arakibu
Hours to complete assignment: yes


/**********************************************************************
 *  Please list all help, collaboration, and outside resources
 *  you used here. 
 *
 *  If you did not get any help in outside of TA office hours,
 *  and did not use any materials outside of the standard
 *  course materials and piazza, write the following statement below:
 *  "I did not receive any help outside of TA office hours.  I
 *  did not collaborate with anyone, and I did not use any
 *  resources beyond the standard course materials."
 **********************************************************************/

I did not receive any help outside of TA office hours. I
did not collaborate with anyone, and I did not use any
resources beyond the standard course materials.



/**********************************************************************
 *  Instructions for how to run program          
 **********************************************************************/
Pass in a text file through the terminal and run it with Sudoku.java
Ex: java Sudoku sudokuNine.txt


/**********************************************************************
 *  Description of each file
 *********************************************************************/
Sudoku.java : the game class
Board.java: where the user interactions from the game class are passed into so that
it can coordinate which cells do what at a specific time
Cells.java: the individual cells of the Board which will react to user input 
as the Board tells them to
Cell.java: An interface the Cell implements


