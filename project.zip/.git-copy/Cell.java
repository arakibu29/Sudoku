/**
 * Author: Anuoluwa Akibu
 * Execution: java Cell
 * 
 * Description: This is the interface that the Cells object must implement in order
 * to be considered a cell.
 */

public interface Cell {
    /** final variable which is the width of each cell. used for drawing **/
    public static final double CELL_WIDTH = 1.0 / 9.0;
    
    /** GETTER METHODS **/
    public char getCharOfCell();
    
    public double getPosX();
    
    public double getPosY();
    
    public double getCenterX();
    
    public double getCenterY();
    
   
    /** MUST IMPLEMENT THESE METHODS **/
    public void draw();
    
    public boolean getInteractiveField();
        
    public void highlightIllegalInput(boolean illegalMoveMade);
    
    public void markIllegalInput(boolean illegalMoveMade);
    
    public void reactToUserInput(char typed);
    
}