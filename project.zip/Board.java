/**
 * Author: Anuoluwa Akibu
 * Execution: java Board, used in java Sudoku
 * 
 * Description: Board is a class that contains the cells of the board. It consists
 * of 81 indvidual cells each of with implement the interface Cell. The Board class
 * is an intermediary and handles what is done when Sudoku is given a user input.
 */

public class Board {
    /** 
     * Board frequently uses the following variables so they are made static and 
     * final. Since the board will always be a 9 x 9 one, the ROW_SIZE is set to 9
     * and the cell width is set to 1/9 for drawing purposes.
     */
    private static final int ROW_SIZE = 9;
    private static final double CELL_WIDTH = 1.0 / 9.0;

    /** FIELDS **/
    private Cell[][] board; // the board that the user will be interacting with
    private Cell[][] initialBoard; // made for the purposes of the end condition

    
    /** CONSTRUCTOR **/ 
    
    // 1. A base Sudoku board from a text file is used to start making the object
    public Board(String sudokuTextFile) {
       
        // 1. Check if the file contains a valid 9x9 board
        if (sudokuTextFile.length() != 89) {
            throw new IllegalArgumentException("Invalid Sudoku Board!");
        }
        
        /** 
         * 2. I will begin to create a 2D array of Cell objects with the following
         * helper variables. Index keeps track of the characters from the file. 
         * xPosition and yPosition keep track of the bottom right corner of each
         * cell whose coordinates will be used to differentiate between whether the
         * user has clicked in the square or not.
         */ 
        int index = 0;
        double xPosition = CELL_WIDTH;
        double yPosition = 8 * CELL_WIDTH;
        
        // the Board is now being made, it is a 2D array of Cell objects
        Cell[][] finalBoard = new Cell[ROW_SIZE][ROW_SIZE];
        
        for (int i = 0; i < ROW_SIZE; i++) {
            for (int j = 0; j < ROW_SIZE; j++) {
                /**
                 * here the cells are being differentiated. if the character from
                 * the file is and including 1-9, then it is not an interactive 
                 * cell (see false), whereas if the character from the file is an 
                 * empty char, then the cell is to be assigned as interactive 
                 * (see true)
                 */
                if (sudokuTextFile.charAt(index) >= '1' && 
                sudokuTextFile.charAt(index) <= '9') {
                    finalBoard[i][j] = new Cells(sudokuTextFile.charAt(index),
                    xPosition, yPosition, false);
                } else {
                    finalBoard[i][j] = new Cells(sudokuTextFile.charAt(index),
                    xPosition, yPosition, true);
                } 
                index++;
                xPosition += CELL_WIDTH;
            } 
            index++;
            xPosition = CELL_WIDTH;
            yPosition -= CELL_WIDTH;
        }
        
        /**
         * 3. Now that the 2D array has been made, it will be error checked to 
         * ensure that the characters within it are valid. The functions used to 
         * do these error checks will be explained later on 
         */
        int rowIndex = 0;
        while (rowIndex < ROW_SIZE) {
            for (int i = 0; i < ROW_SIZE; i++) {
                for (int j = 0; j < ROW_SIZE; j++) {
                    if (isRowValid(finalBoard, i, j) && 
                    isColumnValid(finalBoard, i , j)) {        
                        continue;
                    } else {
                        throw new IllegalArgumentException("Not a valid board!");
                    } 
                }
            }
            rowIndex++;
        }
        
        for (int i = 0; i < ROW_SIZE; i += 3) {
            for (int j = 0; j < ROW_SIZE; j += 3) {
                if (isThreeByThreeValid(finalBoard, i, j)) {
                    continue;
                } else {
                    throw new IllegalArgumentException("Not a valid board!");
                }
            }
        }
        
        // if no exceptions were thrown, the fields can now be instantiated 
        this.board = finalBoard;
        this.initialBoard = finalBoard;
    }
       
    /** METHODS **/
    
    /**
    * Description: A getter method. It retrieves the field board so that in Sudoku
    * the end condition can be checked.
    * 
    * Input: none
    * Output: the field board
    */ 
    public Cell[][] getBoard() {
        return board;
    }
    
    /**
    * Description: returns the String representation of the 2D array board 
    * 
    * Input: none
    * Output: a String that should resemble the text file passed in earlier 
    */   
    public String toString() {
        String outputBoard = "";
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[i].length; j++) {
                outputBoard += board[i][j];
            }
        }
        return outputBoard;
    }
    
    /**
    * Description: Draws the lines and the contents (number or empty spcae)
    * of the cells of the board. The cells are drawn with their draw methods.
    * 
    * Input: none
    * Output:  none
    */ 
    public void draw() {
        PennDraw.setPenColor(PennDraw.BLACK);
        double position = CELL_WIDTH;
        
        int index = 0;
        for (double i = 0.0; i < 0.99; i += position) {
            if (index != 0 && index % 3 == 0) {
                PennDraw.setPenRadius(0.005);
            } else {
                PennDraw.setPenRadius(0.002);
            }
            PennDraw.line(i, 0, i, 1);
            PennDraw.line(0, i, 1, i);  
            index++;
        }
        
        for (int i = 0; i < ROW_SIZE; i++) {
            for (int j = 0; j < ROW_SIZE; j++) {
                board[i][j].draw(); 
            }
        }
    }
    
    /**
    * Description: This method is to be used in Sudoku where it will clear 
    * everything the user has inputted into the board.
    * 
    * Input: none
    * Output: none
    */ 
    public void clearAllInputs() {
        PennDraw.setPenColor(PennDraw.BLACK);
        double position = CELL_WIDTH;

        int index = 0;
        for (double i = 0.0; i < 0.99; i += position) {
            if (index != 0 && index % 3 == 0) {
                PennDraw.setPenRadius(0.005);
            } else {
                PennDraw.setPenRadius(0.002);
            }
            PennDraw.line(i, 0, i, 1);
            PennDraw.line(0, i, 1, i);  
            index++;
        }
        
        for (int i = 0; i < ROW_SIZE; i++) {
            for (int j = 0; j < ROW_SIZE; j++) {
                if (board[i][j].getInteractiveField()) {
                    PennDraw.setPenColor(PennDraw.WHITE);
                    PennDraw.filledSquare(board[i][j].getCenterX(),
                    board[i][j].getCenterY(), CELL_WIDTH / 4.0);
                    PennDraw.setPenColor(PennDraw.BLACK);
                    PennDraw.square(board[i][j].getCenterX(),
                    board[i][j].getCenterY(), CELL_WIDTH / 2.0); 
                } else {
                    board[i][j].draw(); 
                }
            }
        }
    } 
    
    /**
    * Description: To prevent the characters the user has typed from appearing on
    * top of each other, this method draws a white square after each key typed.
    * 
    * Input: the x and y coordinates of the users' click
    * Output: none
    */     
    public void clearLastInput(double mouseX, double mouseY) {
        int row = 0;
        int column = 0;
        for (int i = 0; i < ROW_SIZE; i++) {
            for (int j = 0; j < ROW_SIZE; j++) {
                // this is going through the board to find the cell where the 
                // users' click was within
                if (mouseX < board[i][j].getPosX()  && 
                mouseX > (board[i][j].getPosX() - CELL_WIDTH) && 
                mouseY < (board[i][j].getPosY() + CELL_WIDTH) && 
                mouseY > board[i][j].getPosY()) {
                    row = i;
                    column = j;             
                }    
            }
        }
        
        
        // this ensures that the white square is only drawn if the user had clicked
        // within an interactive cell.
        if (board[row][column].getInteractiveField()) {
            PennDraw.setPenColor(PennDraw.WHITE);
            PennDraw.filledSquare(board[row][column].getCenterX(), 
            board[row][column].getCenterY(), CELL_WIDTH / 3.0);
        }
    }       
    
    
    
    /**
    * Description: This method handles how the cells should react to a users' click
    * and keyboard input. The process is delineated within the code.
    * 
    * Input: the x and y coordinates of the users' click
    * Output: none
    */
    public void reactToInput(double mouseX, double mouseY, char typed) {
        int row = 0;
        int column = 0; 
            // 1. Finds the cell where it's been clicked
            for (int i = 0; i < ROW_SIZE; i++) {
                for (int j = 0; j < ROW_SIZE; j++) {
                    // if the click's coordinate are within a cell's coordinates 
                    // store the row and column
                    if (mouseX < board[i][j].getPosX()  && 
                    mouseX > (board[i][j].getPosX() - CELL_WIDTH) && 
                    mouseY < (board[i][j].getPosY() + CELL_WIDTH) && 
                    mouseY > board[i][j].getPosY()) {
                        row = i;
                        column = j; 
                    }
                }              
            }
        
            // 2. Since typed is initially set to ' ', there's nothing to react to 
            if (typed == ' ') {
                return;
            } else {
                // this first makes sure that the cell clicked can be changed
                if (board[row][column].getInteractiveField()) {
                    // if it can be changed then call the cell to react to the 
                    // keyboard input
                    board[row][column].reactToUserInput(typed);
                }
            }      
            
            /** 
             * 3. This is where the error checks of the keyboard inputs are made.
             * If the key typed is invalid, nothing should occur. If it is valid,
             * then the Board will call it's error checking methods (will be 
             * explained later) on the cell where the number was typed. If there
             * are no erros, then any red marks made before will be removed.
             */
            if (typed < '1' || typed > '9') {
                return; 
            } else {
                if (!isInputValid(board, row, column)) {
                    // this calls the cell clicked on to be drawn in red
                    board[row][column].markIllegalInput(true);
                } else {
                    // this removes any error marks made
                    board[row][column].markIllegalInput(false); 
                }
            }
    }
    
 
    /**
    * Description: This is the overarching error checking method that encapsulates 
    * most of the error checking methods in this class. It returns true if the 
    * key typed was valid and false if not. These boolean values are what are used
    * above to call the cell that was clicked on to either be marked or not. Within
    * isInputValid() are the error checking methods for the rows and the columns.
    * If either is found to contain repeated characters, 1) the row and/or column
    * will be highlighted in red and 2) the conflicting characters will be drawnOnce
    * in red. Once the errors are resolved, the row and column will remove 
    * any corresponding red markings.
    * 
    * Input: the Sudoku board, the row and column of the cell that was clicked
    * Output: true or false depending on if a conflicting character was found
    */
    public boolean isInputValid(Cell[][] board, int row, int column) {     
        boolean valid = true; // since nothing has been checked yet
        
        if (!isRowValid(board, row, column)) {
            valid = false;
            for (int i = 0; i < ROW_SIZE; i++) {
                board[i][column].highlightIllegalInput(true); 
                if (i != row) {
                    if (board[i][column].getCharOfCell() == 
                    board[row][column].getCharOfCell()) {
                        // this is where the conflicting chars are marked red
                        board[i][column].markIllegalInput(true);
                    } else if (board[i][column].getCharOfCell() != board[row][column].getCharOfCell()) {
                        // this is where the highlight is removed if the current 
                        // cell that has been clicked's character no longer
                        // conflicts with what is in the row
                        board[i][column].markIllegalInput(false);
                    } 
                }
            }
        } else { // if nothing was found remove the highlights and markings
            for (int i = 0; i < ROW_SIZE; i++) {
               board[i][column].highlightIllegalInput(false);
               board[i][column].markIllegalInput(false);   
            }
        }
        
        if (!isColumnValid(board, row, column)) {
            valid = false;
            for (int i = 0; i < ROW_SIZE; i++) {
                board[row][i].highlightIllegalInput(true);   
                    if (i != column) {
                        if (board[row][i].getCharOfCell() == 
                        board[row][column].getCharOfCell()) { 
                            board[row][i].markIllegalInput(true);   
                        } else if (board[row][i].getCharOfCell() != 
                        board[row][column].getCharOfCell()) {
                            board[row][i].markIllegalInput(false);
                        }
                    }
                }
            } else {
                for (int i = 0; i < ROW_SIZE; i++) {
                    board[row][i].highlightIllegalInput(false);
                    board[row][i].markIllegalInput(false);   
                }
            }
                         
        return valid;
    }

    /**
    * Description: This is the error checking method for the rows. If a row is 
    * found to have conflicting chars with the users' input, it will return false.
    * 
    * Input: the Sudoku board and the row and column of the cell where the user
    * clicked
    * Output: true or false depnding on if the row is found to be valid or not
    */ 
    public boolean isRowValid(Cell[][] board, int row, int column) {
            char charToCheck = board[row][column].getCharOfCell();
            for (int i = 0; i < ROW_SIZE; i++) { 
                 if (charToCheck == ' ') {
                        break;
                 } else if (i != row) {
                    if (board[i][column].getCharOfCell() == board[row][column].getCharOfCell()) {
                   return false;
                }
            }
        }
        
        return true;
    } 
        
    /**
    * Description: As with isRowValid(), this is the error checking method for the 
    * columns. If a column is found to have conflicting chars with the users' 
    * input, it will return false.
    * 
    * Input: the Sudoku board and the row and column of the cell where the user
    * clicked
    * Output: true or false depnding on if the column is found to be valid or not
    */ 
    public boolean isColumnValid(Cell[][] board, int row, int column) {
        char charToCheck = board[row][column].getCharOfCell();
            for (int i = 0; i < ROW_SIZE; i++) { 
                if (charToCheck == ' ') {
                    break;
                } else if (i != column) {
                    if (board[row][i].getCharOfCell() == board[row][column].getCharOfCell()) {
                        return false;
                    }
                }
            }
       
        return true;
    }
    
    /**
    * Description: This is the error checking method for the grids that make up
    * the board. As with isRowValid() and isColumnValid(), this method checks 
    * whether the keyboard input by the user conflicts with any char already
    * in the grid. It only takes in certain the rows and columns of the upper right
    * cell so that it can create a sub 2D Cell array fromm the inputBoard and
    * check the users' typed key from that.
    * 
    * Input: the Sudoku board and the row and column of the cell where the user
    * clicked
    * Output: true or false depnding on if the grid is found to be valid or not 
    */ 
    public boolean isThreeByThreeValid(Cell[][] inputBoard, int row, int column) {
        if (row % 3 != 0 && column % 3 != 0) {
            throw new IllegalArgumentException("Invalid index!");
        }
        
        char[][] threeByThree = new char[3][3];
        int columnIndex = column;
        for (int i = 0; i < threeByThree.length; i++) {
            for (int j = 0; j < threeByThree[i].length; j++) {
                threeByThree[i][j] = inputBoard[row][column].getCharOfCell();
                column++;
            }
            row++;
            column = columnIndex;
        }
        
        int threeByThreeIndex = threeByThree.length;
        int rowIndex = 0;
        columnIndex = 0;
        while (threeByThreeIndex > 0) {
            char charToCheck = threeByThree[rowIndex][columnIndex];
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (charToCheck == ' ' || (rowIndex == i && columnIndex == j)) {
                        continue; 
                    } else if (charToCheck == threeByThree[i][j]) {
                        return false;
                    }
                }
                threeByThreeIndex--;
            }
            columnIndex++;
            if (columnIndex == 3) {
                rowIndex++;
                columnIndex = 0;
            }
        } 
        return true;
    }
                          
                           
    /**
    * Description: This is the method that will be used in the ending condition of
    * the game. It checks each 3 x 3 grid for incorrect chars and returns a boolean
    * depending on the values found.
    * 
    * Input: the Sudoku board
    * Output: true or false depending on if each grid contains all valid characters 
    */ 
    /** winning board check **/
     public boolean checkWinningBoard(Cell[][] inputBoard) {
         if (inputBoard == initialBoard) {
             return false;
         }
       
         for (int i = 0; i < ROW_SIZE; i += 3) {
             for (int j = 0; j < ROW_SIZE; j+= 3) {
                 if (isThreeByThreeValid(inputBoard, i, j)) {
                     System.out.println("continued");
                     continue;
                 } else {
                     return false;
                 }
             }  
         } 
         return true;
    }  
}
