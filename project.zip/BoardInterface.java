/**
 * Author: Anuoluwa Akibu
 * Execution: java 
 * 
 * Description: 
 */

public interface BoardInterface {
    // it's a 9 x 9 board
    public static final int ROW_SIZE = 9;
    
    
    /** MUST IMPLEMENT METHODS **/ 
    
    /** error checking board  **/
    public boolean isRowValid();
    public boolean isColumnValid();
    public boolean isThreeByThreeValid();
        
    /** draw **/
    public void draw();

    
    /** react to user input / maybe highlight problem numbers here? **/
    /** error checking user input **/
    public void reactToUserInput();
    public void highlightIllegalInput();
    
    /** winning board check **/
    public boolean checkWinningBoard();  
}